import os

TOKEN = os.environ.get("TOKEN")
NAME = "Zyrox X"
server = "https://discord.gg/SF8JKmzjyP"
ch = "https://discord.com/channels/699587669059174461/1271825678710476911"
OWNER_IDS = [952846045124120607,1008438721982500894,1382744437049790495,1263404140965396555]
BotName = "Zyrox X"
serverLink = "https://discord.gg/SF8JKmzjyP"